#include "i2c-lcd.h"
#include "stm32f4xx_hal.h"
#include <string.h>

extern I2C_HandleTypeDef hi2c1;

#define LCD_BACKLIGHT 0x08 // Bit 3 = backlight control
#define LCD_NOBACKLIGHT 0x00

static uint8_t backlight_state = LCD_BACKLIGHT; // default ON

static void lcd_send(uint8_t data, uint8_t rs);
static void lcd_toggle_enable(uint8_t data);

// ------------------- Initialization -------------------
void lcd_init(void) {
HAL_Delay(50); // wait for LCD to power up

lcd_send_cmd(0x33);
lcd_send_cmd(0x32); // initialize 4-bit mode
lcd_send_cmd(0x28); // 2 line, 5x8 matrix
lcd_send_cmd(0x0C); // display on, cursor off
lcd_send_cmd(0x06); // increment cursor
lcd_clear();
}

// ------------------- Basic Commands -------------------
void lcd_send_cmd(char cmd) {
lcd_send(cmd, 0);
}

void lcd_send_data(char data) {
lcd_send(data, 1);
}

void lcd_send_string(char *str) {
while (*str) {
lcd_send_data(*str++);
}
}

void lcd_put_cur(int row, int col) {
char pos;
switch (row) {
case 0: pos = 0x80 + col; break;
case 1: pos = 0xC0 + col; break;
default: pos = 0x80 + col; break;
}
lcd_send_cmd(pos);
}

void lcd_clear(void) {
lcd_send_cmd(LCD_CLEAR);
HAL_Delay(2);
}

// ------------------- Backlight Control -------------------
void lcd_backlight_on(void) {
backlight_state = LCD_BACKLIGHT;
// refresh one dummy write to ensure it applies
uint8_t data = backlight_state;
HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, &data, 1, HAL_MAX_DELAY);
}

void lcd_backlight_off(void) {
backlight_state = LCD_NOBACKLIGHT;
uint8_t data = backlight_state;
HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, &data, 1, HAL_MAX_DELAY);
}

// ------------------- Low-level -------------------
static void lcd_send(uint8_t data, uint8_t rs) {
uint8_t highnib = data & 0xF0;
uint8_t lownib = (data << 4) & 0xF0;

lcd_toggle_enable(highnib | (rs ? 0x01 : 0x00));
lcd_toggle_enable(lownib | (rs ? 0x01 : 0x00));
}

static void lcd_toggle_enable(uint8_t data) {
uint8_t temp = data | 0x04 | backlight_state; // Enable high + backlight
HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, &temp, 1, HAL_MAX_DELAY);
HAL_Delay(1);

temp = (data & ~0x04) | backlight_state; // Enable low + backlight
HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, &temp, 1, HAL_MAX_DELAY);
HAL_Delay(1);
}
