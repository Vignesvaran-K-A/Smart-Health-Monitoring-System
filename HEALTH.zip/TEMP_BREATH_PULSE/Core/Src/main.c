/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Health Monitor with Trending & Pattern Detection
  ******************************************************************************
  * Enhanced with:
  * - EMA filtering for noise reduction
  * - Circular buffers for time-series data
  * - Multi-timeframe trend analysis (5s, 15s, 1min)
  * - Statistical anomaly detection
  * - Pattern recognition (spikes, drops, oscillations)
  * - Severity-based alerting with trend context
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "i2c-lcd.h"
#include "stm32f4xx_hal.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

// Circular Buffer Structure
typedef struct {
    float data[36];  // 36 samples = 3 minutes at 5s intervals
    uint8_t head;
    uint8_t count;
} CircularBuffer;

// Trending Statistics Structure
typedef struct {
    float current;
    float ema;
    float short_avg;
    float long_avg;
    float rate_of_change;  // per minute
    float baseline_mean;
    float baseline_stddev;
    uint8_t trend_direction; // 0=stable, 1=rising, 2=falling
    uint8_t pattern_detected; // 0=none, 1=spike, 2=drop, 3=oscillating
} TrendingData;

// Alert Level Enum
typedef enum {
    ALERT_NONE = 0,
    ALERT_LOW,
    ALERT_MEDIUM,
    ALERT_HIGH,
    ALERT_CRITICAL
} AlertLevel;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// Gaussian Normalization Constants
#define OPTIMAL_TEMP_C   37.0f
#define TEMP_SPREAD      1.5f
#define OPTIMAL_BPM      70.0f
#define BPM_SPREAD       15.0f
#define OPTIMAL_RESP     15.0f
#define RESP_SPREAD      5.0f

// Trending System Configuration
#define BUFFER_SIZE      36     // 36 samples = 3 minutes at 5s intervals
#define EMA_ALPHA        0.3f   // EMA smoothing factor (0.3 = 30% new, 70% old)
#define SHORT_WINDOW     3      // 15 seconds (3 * 5s)
#define LONG_WINDOW      12     // 1 minute (12 * 5s)

// Trend Detection Thresholds
#define TEMP_RATE_WARN   0.5f   // °C per minute
#define BPM_RATE_WARN    10.0f  // BPM per minute
#define RESP_RATE_WARN   3.0f   // breaths/min per minute

#define TEMP_SPIKE_THRESH  1.0f  // °C deviation for spike detection
#define BPM_SPIKE_THRESH   20.0f // BPM deviation for spike detection
#define RESP_SPIKE_THRESH  5.0f  // breaths/min deviation

// DS18B20 and Sensor Pins
#define DS18B20_PORT GPIOB
#define DS18B20_PIN GPIO_PIN_2
#define SOUND_SENSOR_PORT GPIOB
#define SOUND_SENSOR_PIN  GPIO_PIN_0

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
I2C_HandleTypeDef hi2c1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim10;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

// Global Buffers
CircularBuffer temp_buffer = {0};
CircularBuffer bpm_buffer = {0};
CircularBuffer resp_buffer = {0};

// Trending Data
TrendingData temp_trend = {0};
TrendingData bpm_trend = {0};
TrendingData resp_trend = {0};

// Timing Variables
uint32_t last_5s_update = 0;
uint32_t last_15s_analysis = 0;
uint32_t last_1min_analysis = 0;

// Raw Sensor Variables
float Temperature = 0;
uint16_t heartRate = 0;
uint16_t breathCount = 0;
uint8_t Presence = 0;

// Alert State
AlertLevel current_alert = ALERT_NONE;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM10_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

// Circular Buffer Functions
void CB_Init(CircularBuffer *cb);
void CB_Push(CircularBuffer *cb, float value);
float CB_Get(CircularBuffer *cb, uint8_t index);
float CB_Average(CircularBuffer *cb, uint8_t window);
float CB_StdDev(CircularBuffer *cb, uint8_t window);

// EMA Filter
float EMA_Update(float current, float previous, float alpha);

// Trending Analysis
void Trending_Update5s(TrendingData *trend, CircularBuffer *buffer);
void Trending_Analyze15s(TrendingData *trend, CircularBuffer *buffer);
void Trending_Analyze1min(TrendingData *trend, CircularBuffer *buffer);
uint8_t Detect_Pattern(CircularBuffer *buffer, float spike_thresh);

// Health Score & Alerts
float compute_health_score_with_trends(void);
AlertLevel Determine_Alert_Level(float score);
void Handle_Alert(AlertLevel level);

// Sensor Functions
void Delay(uint16_t time);
void Set_Pin_Output(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
void Set_Pin_Input(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
uint8_t DS18B20_Start(void);
void DS18B20_Write(uint8_t data);
uint8_t DS18B20_Read(void);
uint32_t adc_read_raw(void);
void Update_HeartRate(void);
void Update_Breath(void);

// Buzzer Functions
void Buzzer_Start(void);
void Buzzer_Stop(void);
void Buzzer_SetFrequency(uint32_t freq);
void Buzzer_Beep(uint32_t freq, uint32_t duration_ms);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* ============================================================================
   CIRCULAR BUFFER IMPLEMENTATION
   ============================================================================ */

void CB_Init(CircularBuffer *cb) {
    cb->head = 0;
    cb->count = 0;
    memset(cb->data, 0, sizeof(cb->data));
}

void CB_Push(CircularBuffer *cb, float value) {
    cb->data[cb->head] = value;
    cb->head = (cb->head + 1) % BUFFER_SIZE;
    if (cb->count < BUFFER_SIZE) cb->count++;
}

float CB_Get(CircularBuffer *cb, uint8_t index) {
    if (index >= cb->count) return 0.0f;
    uint8_t pos = (cb->head - cb->count + index + BUFFER_SIZE) % BUFFER_SIZE;
    return cb->data[pos];
}

float CB_Average(CircularBuffer *cb, uint8_t window) {
    if (cb->count == 0) return 0.0f;
    uint8_t samples = (window > cb->count) ? cb->count : window;
    float sum = 0.0f;
    for (uint8_t i = 0; i < samples; i++) {
        sum += CB_Get(cb, cb->count - samples + i);
    }
    return sum / samples;
}

float CB_StdDev(CircularBuffer *cb, uint8_t window) {
    if (cb->count < 2) return 0.0f;
    uint8_t samples = (window > cb->count) ? cb->count : window;
    float mean = CB_Average(cb, window);
    float sum_sq_diff = 0.0f;
    for (uint8_t i = 0; i < samples; i++) {
        float diff = CB_Get(cb, cb->count - samples + i) - mean;
        sum_sq_diff += diff * diff;
    }
    return sqrtf(sum_sq_diff / samples);
}

/* ============================================================================
   EMA FILTERING
   ============================================================================ */

float EMA_Update(float current, float previous, float alpha) {
    return alpha * current + (1.0f - alpha) * previous;
}

/* ============================================================================
   PATTERN DETECTION
   ============================================================================ */

uint8_t Detect_Pattern(CircularBuffer *buffer, float spike_thresh) {
    if (buffer->count < 5) return 0; // Not enough data

    float recent_avg = CB_Average(buffer, 3);
    float baseline_avg = CB_Average(buffer, buffer->count);
    float diff = fabsf(recent_avg - baseline_avg);

    // Check for spike/drop
    if (diff > spike_thresh) {
        return (recent_avg > baseline_avg) ? 1 : 2; // 1=spike, 2=drop
    }

    // Check for oscillation (alternating up/down)
    if (buffer->count >= 6) {
        int oscillations = 0;
        for (uint8_t i = buffer->count - 5; i < buffer->count - 1; i++) {
            float curr = CB_Get(buffer, i);
            float next = CB_Get(buffer, i + 1);
            float prev = (i > 0) ? CB_Get(buffer, i - 1) : curr;

            if ((curr > prev && curr > next) || (curr < prev && curr < next)) {
                oscillations++;
            }
        }
        if (oscillations >= 2) return 3; // Oscillating pattern
    }

    return 0; // No pattern
}

/* ============================================================================
   TRENDING ANALYSIS FUNCTIONS
   ============================================================================ */

void Trending_Update5s(TrendingData *trend, CircularBuffer *buffer) {
    if (buffer->count == 0) return;

    // Update EMA
    float new_value = CB_Get(buffer, buffer->count - 1);
    if (trend->ema == 0.0f) {
        trend->ema = new_value; // Initialize
    } else {
        trend->ema = EMA_Update(new_value, trend->ema, EMA_ALPHA);
    }
    trend->current = trend->ema;
}

void Trending_Analyze15s(TrendingData *trend, CircularBuffer *buffer) {
    if (buffer->count < SHORT_WINDOW) return;

    // Calculate short-term average
    trend->short_avg = CB_Average(buffer, SHORT_WINDOW);

    // Calculate rate of change (per minute)
    float old_val = CB_Get(buffer, buffer->count - SHORT_WINDOW);
    float time_min = (SHORT_WINDOW * 5.0f) / 60.0f; // Convert 5s intervals to minutes
    trend->rate_of_change = (trend->current - old_val) / time_min;

    // Determine trend direction
    if (fabsf(trend->rate_of_change) < 0.1f) {
        trend->trend_direction = 0; // Stable
    } else if (trend->rate_of_change > 0) {
        trend->trend_direction = 1; // Rising
    } else {
        trend->trend_direction = 2; // Falling
    }
}

void Trending_Analyze1min(TrendingData *trend, CircularBuffer *buffer) {
    if (buffer->count < LONG_WINDOW) return;

    // Calculate long-term statistics
    trend->long_avg = CB_Average(buffer, LONG_WINDOW);
    trend->baseline_mean = CB_Average(buffer, buffer->count);
    trend->baseline_stddev = CB_StdDev(buffer, buffer->count);
}

/* ============================================================================
   GAUSSIAN NORMALIZATION & HEALTH SCORING
   ============================================================================ */

static inline float clampf(float v, float lo, float hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

float norm_temp_0_1(float temp_c) {
    float num = (temp_c - OPTIMAL_TEMP_C);
    num *= num;
    float den = 2.0f * TEMP_SPREAD * TEMP_SPREAD;
    return clampf(1.0f - expf(-(num / den)), 0.0f, 1.0f);
}

float norm_bpm_0_1(float bpm) {
    float num = (bpm - OPTIMAL_BPM);
    num *= num;
    float den = 2.0f * BPM_SPREAD * BPM_SPREAD;
    return clampf(1.0f - expf(-(num / den)), 0.0f, 1.0f);
}

float norm_resp_0_1(float breaths_per_min) {
    float num = (breaths_per_min - OPTIMAL_RESP);
    num *= num;
    float den = 2.0f * RESP_SPREAD * RESP_SPREAD;
    return clampf(1.0f - expf(-(num / den)), 0.0f, 1.0f);
}

float compute_health_score_with_trends(void) {
    // Base risk scores from current values
    float temp_risk = norm_temp_0_1(temp_trend.current);
    float bpm_risk = norm_bpm_0_1(bpm_trend.current);
    float resp_risk = norm_resp_0_1(resp_trend.current);

    // Add risk from rate of change
    float temp_rate_risk = clampf(fabsf(temp_trend.rate_of_change) / TEMP_RATE_WARN, 0.0f, 1.0f);
    float bpm_rate_risk = clampf(fabsf(bpm_trend.rate_of_change) / BPM_RATE_WARN, 0.0f, 1.0f);
    float resp_rate_risk = clampf(fabsf(resp_trend.rate_of_change) / RESP_RATE_WARN, 0.0f, 1.0f);

    // Pattern risk (spikes and drops increase risk)
    float pattern_risk = 0.0f;
    if (temp_trend.pattern_detected > 0) pattern_risk += 0.2f;
    if (bpm_trend.pattern_detected > 0) pattern_risk += 0.3f;
    if (resp_trend.pattern_detected > 0) pattern_risk += 0.2f;
    pattern_risk = clampf(pattern_risk, 0.0f, 0.5f);

    // Weighted fusion: Base (60%) + Rate (30%) + Pattern (10%)
    float total_risk = 0.6f * (0.2f * temp_risk + 0.5f * bpm_risk + 0.3f * resp_risk)
                     + 0.3f * (0.2f * temp_rate_risk + 0.5f * bpm_rate_risk + 0.3f * resp_rate_risk)
                     + 0.1f * pattern_risk;

    // Convert to health score (100 = best, 0 = worst)
    return clampf((1.0f - total_risk) * 100.0f, 0.0f, 100.0f);
}

/* ============================================================================
   ALERT MANAGEMENT
   ============================================================================ */

AlertLevel Determine_Alert_Level(float score) {
    if (score >= 70.0f) return ALERT_NONE;
    if (score >= 55.0f) return ALERT_LOW;
    if (score >= 40.0f) return ALERT_MEDIUM;
    if (score >= 25.0f) return ALERT_HIGH;
    return ALERT_CRITICAL;
}

void Handle_Alert(AlertLevel level) {
    char msg[64];

    lcd_clear();
    lcd_put_cur(0, 0);

    switch (level) {
        case ALERT_NONE:
            lcd_send_string("  HEALTH NORMAL ");
            sprintf(msg, "Status: NORMAL\r\n");
            break;

        case ALERT_LOW:
            lcd_send_string(" MINOR CONCERN  ");
            lcd_put_cur(1, 0);
            lcd_send_string(" Monitor Closely");
            sprintf(msg, "ALERT: Minor Concern\r\n");
            Buzzer_Beep(1000, 100);
            break;

        case ALERT_MEDIUM:
            lcd_send_string("  CAUTION REQD  ");
            lcd_put_cur(1, 0);
            lcd_send_string(" Check Vitals   ");
            sprintf(msg, "ALERT: Caution Required\r\n");
            Buzzer_Beep(1500, 150);
            HAL_Delay(100);
            Buzzer_Beep(1500, 150);
            break;

        case ALERT_HIGH:
            lcd_send_string("   WARNING!!!   ");
            lcd_put_cur(1, 0);
            lcd_send_string(" Seek Attention ");
            sprintf(msg, "ALERT: WARNING - High Risk\r\n");
            for (int i = 0; i < 3; i++) {
                Buzzer_Beep(2000, 100);
                HAL_Delay(100);
            }
            break;

        case ALERT_CRITICAL:
            lcd_send_string("   CRITICAL!!!  ");
            lcd_put_cur(1, 0);
            lcd_send_string(" IMMEDIATE HELP ");
            sprintf(msg, "ALERT: CRITICAL - Immediate Action\r\n");
            for (int i = 0; i < 5; i++) {
                Buzzer_Beep(2500, 80);
                HAL_Delay(80);
            }
            break;
    }

    HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
    HAL_Delay(2000);
}

/* ============================================================================
   SENSOR READING FUNCTIONS
   ============================================================================ */

void Delay(uint16_t time) {
    __HAL_TIM_SET_COUNTER(&htim10, 0);
    while(__HAL_TIM_GET_COUNTER(&htim10) < time);
}

void Set_Pin_Output(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = GPIO_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

void Set_Pin_Input(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin) {
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = GPIO_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

uint8_t DS18B20_Start(void) {
    uint8_t Response = 0;
    Set_Pin_Output(DS18B20_PORT, DS18B20_PIN);
    HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN, 0);
    Delay(480);
    Set_Pin_Input(DS18B20_PORT, DS18B20_PIN);
    Delay(80);
    if (HAL_GPIO_ReadPin(DS18B20_PORT, DS18B20_PIN) == 0)
        Response = 0;
    else
        Response = 1;
    Delay(400);
    return Response;
}

void DS18B20_Write(uint8_t data) {
    Set_Pin_Output(DS18B20_PORT, DS18B20_PIN);
    for (int i = 0; i < 8; i++) {
        if ((data & (1 << i)) != 0) {
            Set_Pin_Output(DS18B20_PORT, DS18B20_PIN);
            HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN, 0);
            Delay(1);
            Set_Pin_Input(DS18B20_PORT, DS18B20_PIN);
            Delay(60);
        } else {
            Set_Pin_Output(DS18B20_PORT, DS18B20_PIN);
            HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN, 0);
            Delay(60);
            Set_Pin_Input(DS18B20_PORT, DS18B20_PIN);
        }
    }
}

uint8_t DS18B20_Read(void) {
    uint8_t value = 0;
    Set_Pin_Input(DS18B20_PORT, DS18B20_PIN);
    for (int i = 0; i < 8; i++) {
        Set_Pin_Output(DS18B20_PORT, DS18B20_PIN);
        HAL_GPIO_WritePin(DS18B20_PORT, DS18B20_PIN, 0);
        Delay(2);
        Set_Pin_Input(DS18B20_PORT, DS18B20_PIN);
        if (HAL_GPIO_ReadPin(DS18B20_PORT, DS18B20_PIN)) {
            value |= (1 << i);
        }
        Delay(60);
    }
    return value;
}

uint32_t adc_read_raw(void) {
    uint32_t val = 0;
    HAL_ADC_Start(&hadc1);
    if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK) {
        val = HAL_ADC_GetValue(&hadc1);
    }
    HAL_ADC_Stop(&hadc1);
    return val;
}

void Update_HeartRate(void) {
    uint32_t adcVal = adc_read_raw();
    heartRate = (uint16_t)((adcVal * 60.0f / 4095.0f) + 40.0f); // Map 0-4095 to 40-100 BPM
}

void Update_Breath(void) {
    if (HAL_GPIO_ReadPin(SOUND_SENSOR_PORT, SOUND_SENSOR_PIN) == GPIO_PIN_SET) {
        breathCount++;
        HAL_Delay(100);
    }
}

/* ============================================================================
   BUZZER FUNCTIONS
   ============================================================================ */

void Buzzer_Start(void) {
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
}

void Buzzer_Stop(void) {
    HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_2);
}

void Buzzer_SetFrequency(uint32_t freq) {
    uint32_t timer_clk = 1000000;
    uint32_t period = (timer_clk / freq) - 1;
    __HAL_TIM_SET_AUTORELOAD(&htim2, period);
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, period / 2);
}

void Buzzer_Beep(uint32_t freq, uint32_t duration_ms) {
    Buzzer_SetFrequency(freq);
    Buzzer_Start();
    HAL_Delay(duration_ms);
    Buzzer_Stop();
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/
  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_TIM10_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */

  HAL_TIM_Base_Start(&htim10);

  // Initialize LCD
  lcd_init();
  lcd_clear();
  lcd_put_cur(0, 0);
  lcd_send_string("    ADVANCED    ");
  lcd_put_cur(1, 0);
  lcd_send_string(" HEALTH MONITOR ");
  HAL_Delay(2000);

  lcd_clear();
  lcd_put_cur(0, 0);
  lcd_send_string("  Initializing  ");
  lcd_put_cur(1, 0);
  lcd_send_string("    Buffers...  ");
  HAL_Delay(1000);

  // Initialize buffers
  CB_Init(&temp_buffer);
  CB_Init(&bpm_buffer);
  CB_Init(&resp_buffer);

  // UART startup message
  char uart_msg[64];
  sprintf(uart_msg, "\r\n=== Advanced Health Monitor Started ===\r\n");
  HAL_UART_Transmit(&huart2, (uint8_t*)uart_msg, strlen(uart_msg), 100);
  sprintf(uart_msg, "Features: EMA, Trending, Pattern Detection\r\n");
  HAL_UART_Transmit(&huart2, (uint8_t*)uart_msg, strlen(uart_msg), 100);
  sprintf(uart_msg, "Update Intervals: 5s/15s/1min\r\n\r\n");
  HAL_UART_Transmit(&huart2, (uint8_t*)uart_msg, strlen(uart_msg), 100);

  last_5s_update = HAL_GetTick();
  last_15s_analysis = HAL_GetTick();
  last_1min_analysis = HAL_GetTick();

  lcd_clear();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

    uint32_t now = HAL_GetTick();

    /* ========================================================================
       EVERY 5 SECONDS: Read Sensors, Apply EMA, Store in Buffers
       ======================================================================== */
    if (now - last_5s_update >= 5000) {
        last_5s_update = now;

        // --- Read Temperature (DS18B20) ---
        Presence = DS18B20_Start();
        if (Presence == 0) {
            DS18B20_Start();
            HAL_Delay(1);
            DS18B20_Write(0xCC);
            DS18B20_Write(0x44);
            HAL_Delay(750); // Conversion time

            DS18B20_Start();
            HAL_Delay(1);
            DS18B20_Write(0xCC);
            DS18B20_Write(0xBE);

            uint8_t Temp_byte1 = DS18B20_Read();
            uint8_t Temp_byte2 = DS18B20_Read();
            uint16_t TEMP = (Temp_byte2 << 8) | Temp_byte1;
            Temperature = (float)TEMP / 16.0f;
        } else {
            Temperature = 36.5f; // Fallback if sensor missing
        }

        // --- Read Heart Rate (ADC) ---
        Update_HeartRate();

        // --- Read Breathing Rate (5 second count) ---
        breathCount = 0;
        for (int i = 0; i < 50; i++) {
            Update_Breath();
            HAL_Delay(100);
        }
        float breaths_per_min = (float)breathCount * 12.0f; // 5s to 60s conversion

        // --- Push to circular buffers ---
        CB_Push(&temp_buffer, Temperature);
        CB_Push(&bpm_buffer, (float)heartRate);
        CB_Push(&resp_buffer, breaths_per_min);

        // --- Update EMA filters ---
        Trending_Update5s(&temp_trend, &temp_buffer);
        Trending_Update5s(&bpm_trend, &bpm_buffer);
        Trending_Update5s(&resp_trend, &resp_buffer);

        // --- Quick display update ---
        lcd_clear();
        char line[17];
        sprintf(line, "T:%.1fC HR:%u", temp_trend.current, (uint16_t)bpm_trend.current);
        lcd_put_cur(0, 0);
        lcd_send_string(line);
        sprintf(line, "Breath:%.0f/min", resp_trend.current);
        lcd_put_cur(1, 0);
        lcd_send_string(line);

        // Log to UART
        sprintf(line, "[5s] T:%.1f HR:%u R:%.0f\r\n",
                temp_trend.current, (uint16_t)bpm_trend.current, resp_trend.current);
        HAL_UART_Transmit(&huart2, (uint8_t*)line, strlen(line), 100);
    }

    /* ========================================================================
       EVERY 15 SECONDS: Short-term Trend Analysis
       ======================================================================== */
    if (now - last_15s_analysis >= 15000) {
        last_15s_analysis = now;

        Trending_Analyze15s(&temp_trend, &temp_buffer);
        Trending_Analyze15s(&bpm_trend, &bpm_buffer);
        Trending_Analyze15s(&resp_trend, &resp_buffer);

        // Display trend info
        HAL_Delay(1500);
        lcd_clear();
        char trend_msg[64];
        const char* temp_dir = (temp_trend.trend_direction == 1) ? "UP" :
                               (temp_trend.trend_direction == 2) ? "DN" : "OK";
        const char* bpm_dir = (bpm_trend.trend_direction == 1) ? "UP" :
                              (bpm_trend.trend_direction == 2) ? "DN" : "OK";

        sprintf(trend_msg, "Trend T:%s HR:%s", temp_dir, bpm_dir);
        lcd_put_cur(0, 0);
        lcd_send_string(trend_msg);

        sprintf(trend_msg, "Rate: %.1f/min", bpm_trend.rate_of_change);
        lcd_put_cur(1, 0);
        lcd_send_string(trend_msg);

        // Log to UART
        sprintf(trend_msg, "[15s] Trends - T:%s(%.2f) HR:%s(%.1f) R:%s(%.1f)\r\n",
                temp_dir, temp_trend.rate_of_change,
                bpm_dir, bpm_trend.rate_of_change,
                (resp_trend.trend_direction == 1) ? "UP" :
                (resp_trend.trend_direction == 2) ? "DN" : "OK",
                resp_trend.rate_of_change);
        HAL_UART_Transmit(&huart2, (uint8_t*)trend_msg, strlen(trend_msg), 100);

        HAL_Delay(2000);
    }

    /* ========================================================================
       EVERY 1 MINUTE: Comprehensive Analysis & Alert Check
       ======================================================================== */
    if (now - last_1min_analysis >= 60000) {
        last_1min_analysis = now;

        Trending_Analyze1min(&temp_trend, &temp_buffer);
        Trending_Analyze1min(&bpm_trend, &bpm_buffer);
        Trending_Analyze1min(&resp_trend, &resp_buffer);

        // Detect patterns
        temp_trend.pattern_detected = Detect_Pattern(&temp_buffer, TEMP_SPIKE_THRESH);
        bpm_trend.pattern_detected = Detect_Pattern(&bpm_buffer, BPM_SPIKE_THRESH);
        resp_trend.pattern_detected = Detect_Pattern(&resp_buffer, RESP_SPIKE_THRESH);

        // Display pattern detection
        if (temp_trend.pattern_detected || bpm_trend.pattern_detected || resp_trend.pattern_detected) {
            lcd_clear();
            lcd_put_cur(0, 0);
            lcd_send_string(" PATTERN DETECT ");
            lcd_put_cur(1, 0);
            if (temp_trend.pattern_detected == 1) lcd_send_string("  Temp Spike!  ");
            else if (temp_trend.pattern_detected == 2) lcd_send_string("  Temp Drop!   ");
            else if (bpm_trend.pattern_detected == 1) lcd_send_string("   HR Spike!   ");
            else if (bpm_trend.pattern_detected == 2) lcd_send_string("   HR Drop!    ");
            else if (resp_trend.pattern_detected == 3) lcd_send_string(" Resp Oscill.  ");
            HAL_Delay(2000);
        }

        // Compute comprehensive health score with trends
        float health_score = compute_health_score_with_trends();

        // Determine alert level
        AlertLevel alert = Determine_Alert_Level(health_score);
        current_alert = alert;

        // Display baseline statistics
        lcd_clear();
        lcd_put_cur(0, 0);
        lcd_send_string("  STATISTICS   ");
        char stats[17];
        sprintf(stats, "Mean:T%.1f H%u", temp_trend.baseline_mean, (uint16_t)bpm_trend.baseline_mean);
        lcd_put_cur(1, 0);
        lcd_send_string(stats);
        HAL_Delay(2000);

        // Display health score
        lcd_clear();
        lcd_put_cur(0, 0);
        lcd_send_string(" HEALTH SCORE  ");
        char score_line[17];
        sprintf(score_line, "Score: %.1f/100", health_score);
        lcd_put_cur(1, 0);
        lcd_send_string(score_line);

        // Log comprehensive analysis to UART
        char log[128];
        sprintf(log, "\r\n[1min] === COMPREHENSIVE ANALYSIS ===\r\n");
        HAL_UART_Transmit(&huart2, (uint8_t*)log, strlen(log), 100);

        sprintf(log, "Temp: %.1fC (mean:%.1f std:%.2f)\r\n",
                temp_trend.current, temp_trend.baseline_mean, temp_trend.baseline_stddev);
        HAL_UART_Transmit(&huart2, (uint8_t*)log, strlen(log), 100);

        sprintf(log, "HR: %u bpm (mean:%.0f std:%.1f)\r\n",
                (uint16_t)bpm_trend.current, bpm_trend.baseline_mean, bpm_trend.baseline_stddev);
        HAL_UART_Transmit(&huart2, (uint8_t*)log, strlen(log), 100);

        sprintf(log, "Resp: %.0f/min (mean:%.1f std:%.1f)\r\n",
                resp_trend.current, resp_trend.baseline_mean, resp_trend.baseline_stddev);
        HAL_UART_Transmit(&huart2, (uint8_t*)log, strlen(log), 100);

        sprintf(log, "Health Score: %.1f/100\r\n", health_score);
        HAL_UART_Transmit(&huart2, (uint8_t*)log, strlen(log), 100);

        sprintf(log, "Alert Level: %d\r\n", alert);
        HAL_UART_Transmit(&huart2, (uint8_t*)log, strlen(log), 100);

        if (temp_trend.pattern_detected || bpm_trend.pattern_detected || resp_trend.pattern_detected) {
            sprintf(log, "Patterns: T:%u HR:%u R:%u\r\n",
                    temp_trend.pattern_detected, bpm_trend.pattern_detected, resp_trend.pattern_detected);
            HAL_UART_Transmit(&huart2, (uint8_t*)log, strlen(log), 100);
        }

        sprintf(log, "===================================\r\n\r\n");
        HAL_UART_Transmit(&huart2, (uint8_t*)log, strlen(log), 100);

        HAL_Delay(2000);

        // Handle alert with appropriate response
        Handle_Alert(alert);
    }

    // Small delay to prevent tight loop
    HAL_Delay(100);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 50;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 71;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 999;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 500;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_TIM_MspPostInit(&htim2);
}

/**
  * @brief TIM10 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM10_Init(void)
{
  htim10.Instance = TIM10;
  htim10.Init.Prescaler = 50-1;
  htim10.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim10.Init.Period = 0xffff-1;
  htim10.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim10.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim10) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif /* USE_FULL_ASSERT */