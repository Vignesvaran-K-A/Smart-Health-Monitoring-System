#ifndef INC_I2C_LCD_H_
#define INC_I2C_LCD_H_

#include "stm32f4xx_hal.h"

// I2C handle (use the same as in CubeMX)
extern I2C_HandleTypeDef hi2c1;

// LCD parameters
#define LCD_ADDR (0x27 << 1) // I2C address of LCD (shifted for HAL)
#define LCD_COLS 16
#define LCD_ROWS 2

// LCD commands
#define LCD_CLEAR 0x01
#define LCD_HOME 0x02

// Function prototypes
void lcd_init(void);
void lcd_send_cmd(char cmd);
void lcd_send_data(char data);
void lcd_send_string(char *str);
void lcd_put_cur(int row, int col);
void lcd_clear(void);

#endif /* INC_I2C_LCD_H_ */
